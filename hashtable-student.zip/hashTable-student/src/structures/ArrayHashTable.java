package structures;

// this class demonstrates using an object's hash code to calculate the 
// index into the array

public class ArrayHashTable<K, V> implements HashTable<K, V> {

  protected static final int defaultCapacity = 10;
  protected static final double defaultLoadFactor = 0.7;
  protected static final String defaultCollisionHandler = "linear";

  protected K[] keyTable;
  protected V[] valueTable;
  protected int capacity;
  protected boolean[] flag;
  protected String collisionHandler;
  protected double loadFactorLimit;
  protected int count;

  /**
   * Default Constructor.
   */
  @SuppressWarnings("unchecked")
  public ArrayHashTable() {
    this(defaultCapacity, defaultLoadFactor, defaultCollisionHandler);
    capacity = defaultCapacity;
    keyTable = (K[]) new Object[capacity];
    valueTable = (V[]) new Object[capacity];
    flag = new boolean[capacity];
    collisionHandler = defaultCollisionHandler;
    loadFactorLimit = defaultLoadFactor;
    count = 0;
  }

  /**
   * Default Constructor.
   */
  @SuppressWarnings("unchecked")
  public ArrayHashTable(String collisionHandler) {
    capacity = defaultCapacity;
    keyTable = (K[]) new Object[capacity];
    valueTable = (V[]) new Object[capacity];
    flag = new boolean[capacity];
    this.collisionHandler = collisionHandler;
    loadFactorLimit = defaultLoadFactor;
    count = 0;
  }

  /**
   * Default Constructor.
   */
  @SuppressWarnings("unchecked")
  public ArrayHashTable(int capacity, String collisionHandler){
    this.capacity = capacity;
    keyTable = (K[]) new Object[capacity];
    valueTable = (V[]) new Object[capacity];
    flag = new boolean[capacity];
    this.collisionHandler = collisionHandler;
    loadFactorLimit = defaultLoadFactor;
    count = 0;
  }

  
  /**
   * Constructor.
   */
  @SuppressWarnings("unchecked")
  public ArrayHashTable(int capacity, double loadFactor, String collisionHandler){
    this.capacity = capacity;
    keyTable = (K[]) new Object[capacity];
    valueTable = (V[]) new Object[capacity];
    flag = new boolean[capacity];
    this.collisionHandler = collisionHandler;
    this.loadFactorLimit = loadFactor;
    count = 0;
  }
 
  /** 
  * This method ensures that the inputNum maps to
  * a return value that is in the current array.
  */
  private int getBoundedHash(int inputNum) {
    return Math.abs(inputNum) % this.capacity;
  }
  
  private int getHash(K key) {
    int index = getBoundedHash(key.hashCode());
    return index;
  }
  
  public K[] getKeyTable() {
    return this.keyTable;
  }
  
  public V[] getValueTable() {
    return this.valueTable;
  }
  
  public boolean[] getFlag() {
    return this.flag;
  }

  /** 
   * Returns the number of elements in the hash table.
   */
  public int size() {
    return this.count;
  }

  /**
   * Returns the current maximal number of elements the hash table can save.
   * @return
   */
  public int getCapacity() {
    return this.capacity;
  }

  /**
   * Returns the name of the collision handler for the current hash table. 
   * @return : name of the collision handler.
   */
  public String getCollisionHandlerName() {
    return collisionHandler;
  }

  /**
   * Enlarges the size of the array and rehash.
   */
  @SuppressWarnings("unchecked")
  private void resizeArray() {
    capacity *= 2;
    V[] newValue = valueTable;
    valueTable = (V[]) new Object[capacity];
    K[] newKey = keyTable;
    keyTable = (K[]) new Object[capacity];
    boolean[] Flag = flag;
    flag = new boolean[capacity];
    count = 0;
    for (int i = 0; i < newKey.length; i++) {
      if (Flag[i]) {
        put(newKey[i], newValue[i]);
      }
    }
  }

  /**
  * Calculates the ratio of the size of the data in the table to the capacity.
  */
  private double calcCurrentLoad() {
    return (double) count / capacity;
  } 

  /**
   * This method calls upon a collision resolution scheme
   * to put this value into the table.
   */
  private int resolveCollision(int index, K key) {
    if (this.collisionHandler.equals("linear")) {
      index = doLinearProbe(index);
    } else if (this.collisionHandler.equals("quadratic")) {
      index = doQuadraticProbe(index);
    } else if (this.collisionHandler.equals("doublehash")) {
      index = doDoubleHash(index, key);
    } else { 
      return -1; 
    }
    return index;
  }

  /** 
   * Put the new value into the hash table. Before adding, 
   * resize the array if the current load factor is larger than loadFactorLimit. 
   * Please use the getHash method provided to get the hash for the array index.
   * Call the searchIndex method to see if a collision occurs. 
   * If the key exists in the hash table, replace the old value with the input value.
   * Call the resolveCollision method if a collision happened.
   */
  public void put(K key, V value) {
    if (calcCurrentLoad() > loadFactorLimit) {
      this.resizeArray();
    }
    int j = getHash(key);
    if (searchIndex(j, key) > -1) {
      j  = searchIndex(j, key);
      count--;
    } else if (flag[j]) {
      j = resolveCollision(j, key);
    }
    keyTable[j] = key;
    valueTable[j] = value;
    flag[j] = true;
    count++;
  }

  /** 
   * This method calls upon a collision resolution scheme
   * to search for an index where the value can be inserted into the table.
   */
  private int searchIndex(int index, K value) {
    if (this.collisionHandler.equals("linear")) {
      index = doLinearSearch(index, value);
    } else if (this.collisionHandler.equals("quadratic")) {
      index = doQuadraticSearch(index, value);
    } else if (this.collisionHandler.equals("doublehash")) {
      index = doSecondHashSearch(index, value);
    }
    return index;
  }

  /**
   * Removes the target value from the hash table and return the value.
   * Throws ElementNotFoundException if the target does not exist in the table.
   * Calls searchIndex to get the index in case a collision occurred when
   * the value was put into the table.
   */
  public V remove(K target)throws ElementNotFoundException {
    int j = searchIndex(getHash(target), target);
    if (j == -1) {
      throw new ElementNotFoundException("ElementNotFound");
    }
    flag[j] = false;
    count--;
    return valueTable[j];
  }

  /**
   * Returns the value if it exists in the table.
   * Returns null if the target does not exist in the table.
   * Calls searchIndex to get the index in case a collision occurred when
   * the value was put into the table.
   */
  public V get(K target) {
    int j = searchIndex(getHash(target), target);
    if (j == -1) {
      return null;
    }
    return valueTable[j];
  }

  /** 
  * Start at index and search linearly (with probe length = 1) until an open spot
  * is found. A spot will be found because the table 
  * is never more full than the Load Factor, assuming it's <1.0
  */
  private int doLinearProbe(int index) {
    while (flag[index]) {
      index = (index + 1) % capacity;
    }
    return index;
  }
 
  /**
  * Start at index and search quadratically until an open spot is found
  * A spot will be found because the table 
  * is never more full than the Load Factor, assuming it's <1.0
  */
  private int doQuadraticProbe(int index) {
    int i = 1;
    int j = index;
    while (flag[index]) {
      index = (j + i * i) % capacity;
      i++;
    }
    return index;
  }


  /**
  * If the first hash resulted in a collision, use a second hash
  * as the probe length until a space is found. 
  * The second hash value is computed by length of value.hashCode()
  */
  private int doDoubleHash(int index, K key) {
    int i = String.valueOf(key.hashCode()).length(); 
    while (flag[index]) { 
      index = (index + i) % capacity; 
    }
    return index;
  }  

  /**
  * Start at startIndex and search linearly until the target
  * is found. Return -1 if not found.
  */
  private int doLinearSearch(int startIndex, K target) {
    if (keyTable[startIndex] == target && flag[startIndex]) {
      return startIndex;
    }
    int i = startIndex;
    while (keyTable[i] != null) {
      if (keyTable[i].equals(target) && flag[i]) {
        return i;
      }
      i = (i + 1) % capacity;
      if (i == startIndex) {
        return -1;
      }
    }
   return -1;
  }

  /**
  * Start at startIndex and search quadratically until the target
  * is found. Return -1 if not found.
  */
  private int doQuadraticSearch(int startIndex, K target) {
    if (keyTable[startIndex] == target && flag[startIndex]) {
      return startIndex;
    }
    int q = 1;
    int i = startIndex;
    while (valueTable[i] != null) {
      if (keyTable[i].equals(target) && flag[i]) {
        return i;
      }
      i = (startIndex + q * q) % capacity;
      q++;
      if (i == startIndex) {
        return -1;
      }
    }
    return -1;
  }

  private int doSecondHashSearch(int startIndex, K target) {
    if (keyTable[startIndex] == target && flag[startIndex]) {
      return startIndex;
    }
    int j = String.valueOf(target.hashCode()).length();
    int i = startIndex;
    while (valueTable[i] != null) {
      if (keyTable[i].equals(target) && flag[i]) {
        return i;
      }
      i = (i + j) % capacity;
      if (i == startIndex) {
        return -1;
      }
    }
    return -1;
  }

  /**
   * Return all available keys in hash table as an array.
   */
  @SuppressWarnings("unchecked")
  public K[] keys() {
    K[] temp = (K[]) new Object[count];
    int j = 0;
    for (int i = 0; i < capacity; i++) {
      if (flag[i] == false) {
        continue;
      }
      temp[j] = keyTable[i];
      j++;
    }
    return temp;
  }
}
